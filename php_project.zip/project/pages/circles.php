<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Kinder Surprise - {Page}</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="css/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="css/plugins/timeline.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/main.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<?php 
$con = mysqli_connect("localhost", "simpy", "password", "kinder_garden") or die("Error " . mysqli_error($con));
$get_id=$_GET['sectionID'];
$sql = "SELECT * FROM sections where  id_section = '$get_id'";
$result = mysqli_query($con,$sql);
while($row = mysqli_fetch_array($result)) {
    $title = $row['name_of_section'];
    $description = $row['short_info'];
    $path= $row['icon_path'];
}
?>
<body>
    <div class="container-fluid">
        <div class="well well-lg">
            <div class="row">
                <div class="col-sm-2 col-md-2">
                    <table>
                        <tr>
                            <td>
                                <div class="imgContainer">
                                    <div>
                                        <img src="<?php echo $path; ?>" class="img-thumbnail"  alt="Profile Img">
                                    </div>
                                </div>
                </div>
                </td>
                <td>
                </td>
                </tr>
                </table>
            </div>
            <div class="col-sm-10 col-md-10"> 
                <span class="caption"><?php echo $title; ?></span>
            </div>
            <div class="col-sm-10 col-md-10">
                <div class="container-fluid">
                    <p class="type-value">Main info:</p>
                    <span class="value"> 
         <?php echo $description; ?>
                    </span>

                </div>
                <span class="type-value">List of circle</span>
                <div class="container-fluid">
                    <table class="table table-bordered">
                        <tbody class="value">
                           <?php 
$sql = "SELECT * FROM list_of_section inner join child where list_of_section.id_child=child.id_child and list_of_section.id_section = '$get_id'";
$result = mysqli_query($con,$sql);
while($row = mysqli_fetch_array($result)) {
    $name = $row['first_name'];
    $surname = $row['surname'];
    $birthday= $row['birthday'];
    ?>
  <tr>
             <td> <?php echo $surname." ".$name; ?></td>
             <td><?php echo $birthday; ?></td>
           </tr>
    <?php
}
                           ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    </div>


    </div>
    </div>
    </div>

    <div class="container-fluid">


        <div class="row">

            <div class="col-xs-12">
                <div class="form-group">
                    <label class="add-post">Новая запись</label>
                    <textarea class="form-control" rows="3"></textarea>
                </div>

            </div>

        </div>
        <button type="submit" class="btn btn-default">Submit Button</button>
        <hr>
        <div class="row">


            <div class="col-xs-12">
                <div class="well text">
                    <p>Информация</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum tincidunt est vitae ultrices accumsan. Aliquam ornare lacus adipiscing, posuere lectus et, fringilla augue.</p>
                </div>
            </div>
        </div>


</body>

</html>
