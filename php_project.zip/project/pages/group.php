<div class="well">
	<div class="groupbody">
		<div class="conteiner-fluid">
			<div class="row">
				<div class="col-xs-12  col-md-6 col-lg-4">
					<img src="img/Penguins.jpg" class="img-thumbnail" alt="There is no group`s page photo">

				</div>
				<div class="col-xs-12 col-md-6 col-lg-8">
					<p class="caption">
						Name of group
					</p>
					<hr>
					<div class="container-fluid">
						<p class="type-value">Main info:</p>
						<span class="value"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diem
							nonummy nibh euismod tincidunt ut lacreet dolore magna aliguam erat volutpat.
							Ut wisis enim ad minim veniam, quis nostrud exerci tution.</span>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-md-12 col-lg-12">
					<p class="caption">
						List of group
					</p>
				</div>
			</div>
			<div class="row">
				<div class="container-fluid">
					<div class="table-responsive">
						<table class="table table-striped table-bordered table-hover">
							<thead>
								<tr>
									<th>#</th>
									<th>Last Name</th>
									<th>First Name</th>
									<th>Age</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>1</td>
									<td>Otto</td>
									<td>Mark</td>
									<td>1</td>
								</tr>
								<tr>
									<td>2</td>
									<td>Thornton</td>
									<td>Jacob</td>
									<td>2</td>
								</tr>
								<tr>
									<td>3</td>
									<td>the Bird</td>
									<td>Larry</td>
									<td>4</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
