<div class="well well-lg">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-12 col-sm-6 col-lg-4">
				<div class="thumbnail">
					<img src="img/kidIcon.jpg" class=" col-xs-12" alt="Profile Img">
				</div>
				<div>
					<button type="button" class="btn btn-default btn-block" data-toggle="modal" data-target="#myModal">Edit info</button>
				</div>
			</div>
			<!-- Modal -->
			<div class="modal fade" id="myModal" role="dialog" >
				<div class="modal-dialog">
					<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">Edit information </h4>
						</div>
						<div class="modal-body">
						<form>
							<div class="col-md-12 text-center">
								<div id="profileToggle" class="btn-group btn-toggle"> 
									<button class="btn btn-primary active ">Personal Info</button>
									<button class="btn btn-default">&nbsp Parent Info &nbsp</button>
								</div>
							</div>
							<div id="personalInfo">
								<div class="form-group">
									<label>Name</label>
									<input class="form-control" id="kidName" pattern="[A-Za-z]{1,32}" placeholder="Vasiliy" required class="form-control">
								</div>
								<div class="form-group">
									<label>Middlename</label>
									<input class="form-control" id="kidMidName" pattern="[A-Za-z]{1,32}" placeholder="Gavrilovich" required class="form-control"> 
								</div>
								<div class="form-group">
									<label>Surname</label>
									<input class="form-control" id="kidSurname" pattern="[A-Za-z]{1,32}" placeholder="Nikonov" required class="form-control">
								</div>
								<div class="form-group">
									<label>Home address</label>
									<input class="form-control" id="kidAddress" placeholder="Evergreen terrace 742" required class="form-control">
								</div>
							</div>
							<div id="parentInfo" style="display:none;">
								<div class="row">
									<div class="col-md-12">
									<div class="content">
										<div class="form-group">
											<label>Mum`s name</label>
											<input class="form-control" id="relativeName" pattern="[A-Za-z]{1,32}" placeholder="Vasiliy">
										</div>
										<div class="form-group">
											<label>Mum`s middlename</label>
											<input class="form-control" id="relativeMdlName" pattern="[A-Za-z]{1,32}" placeholder="Gavrilovich">
										</div>
										<div class="form-group">
											<label>Mum`s surname</label>
											<input class="form-control" id="relativeSurname" pattern="[A-Za-z]{1,32}" placeholder="Nikonov">
										</div>
										<div class="form-group">
											<label>Mum`s address</label>
											<input class="form-control" id="relativeAddress" placeholder="Evergreen terrace 742">
										</div>
										<div class="form-group">
											<label>Mum`s telephone number</label>
											<input class="form-control" type="tel" pattern="(\+?\d[- .]*){7,13}" id="relativeCell" placeholder="+380504547823">
										</div>
										<div class="form-group">
											<label>Mum`s work address</label>
											<input class="form-control" id="relativeWorkAddress" placeholder="Evergreen terrace 742">
										</div>
										<div class="form-group">
											<label>Mum`s work position</label>
											<input class="form-control" pattern="[A-Za-z]{1,32}" id="relativeWorkPosition" placeholder="Boss">
										</div>
										<div class="form-group">
											<label>Mum`s work telephone</label>
											<input class="form-control" id="relativeWorkCell" type="tel" pattern="(\+?\d[- .]*){7,13}" placeholder="+380504547823">
										</div>
									</div>	
									<div class="content">
										<div class="form-group">
											<label>Father`s name</label>
											<input class="form-control" pattern="[A-Za-z]{1,32}" id="relativeName" placeholder="Vasiliy">
										</div>
										<div class="form-group">
											<label>Father`s middlename</label>
											<input class="form-control" pattern="[A-Za-z]{1,32}" id="relativeMdlName" placeholder="Gavrilovich">
										</div>
										<div class="form-group">
											<label>Father`s surname</label>
											<input class="form-control" pattern="[A-Za-z]{1,32}" id="relativeSurname" placeholder="Nikonov">
										</div>
										<div class="form-group">
											<label>Father`s address</label>
											<input class="form-control" id="relativeAddress" placeholder="Evergreen terrace 742">
										</div>
										<div class="form-group">
											<label>Father`s telephone number</label>
											<input class="form-control" type="tel" pattern="(\+?\d[- .]*){7,13}" id="relativeCell" placeholder="+380504547823">
										</div>
										<div class="form-group">
											<label>Father`s work address</label>
											<input class="form-control"  id="relativeWorkAddress" placeholder="Evergreen terrace 742">
										</div>
										<div class="form-group">
											<label>Father`s work position</label>
											<input class="form-control" pattern="[A-Za-z]{1,32}" id="relativeWorkPosition" placeholder="Boss">
										</div>
										<div class="form-group">
											<label>Father`s work telephone</label>
											<input class="form-control" pattern="(\+?\d[- .]*){7,13}" id="relativeWorkCell"  placeholder="+380504547823">
										</div>
									</div>
									</div>
	<div class="col-md-12">
									<nav class="text-center">
    <ul class="pagination">
        <li class="pag_prev">
            <a href="#" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
            </a>
        </li>
        <li class="pag_next">
            <a href="#" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
            </a>
        </li>
    </ul>
</nav>
									</div>
								</div>
							</div>
							<div class="modal-footer">
							<button type="submit" class="btn btn-primary btn-lg btn-block">Save changes</button>
						</div>
						</form>
						</div>
						
					</div>
				</div>

			</div>
			<!-- </div> -->
			
			<div class="col-xs-12 col-sm-6 col-lg-8">
				<p class="caption">Lastname Firstname</p>
				<hr>
				<div class="container-fluid">
					<p class="type-value">Info about parents:</p>
					<p class="value">Lorem ipsum dolor sit amet, eu quem accumsan adipisci ius, per erroribus quaerendum in. Ne paulo invidunt nam. Primis facete philosophia et sed, pri feugait lobortis cu. His agam viderer et. Hinc idque feugiat te vis, has ei dicit legendos. Cu nullam blandit duo, eam aperiri petentium argumentum ut, cum quas probo in.</p>
					<p class="type-value">Info about child:</p>
					<p class="value">Lorem ipsum dolor sit amet, eu quem accumsan adipisci ius, per erroribus quaerendum in. Ne paulo invidunt nam. Primis facete philosophia et sed, pri feugait lobortis cu. His agam viderer et. Hinc idque feugiat te vis, has ei dicit legendos. Cu nullam blandit duo, eam aperiri petentium argumentum ut, cum quas probo in.</p>
					<p class="type-value">Group info:</p>
					<p class="value">Lorem ipsum dolor sit amet, eu quem accumsan adipisci ius, per erroribus quaerendum in. Ne paulo invidunt nam. Primis facete philosophia et sed, pri feugait lobortis cu. His agam viderer et. Hinc idque feugiat te vis, has ei dicit legendos. Cu nullam blandit duo, eam aperiri petentium argumentum ut, cum quas probo in.</p>
					<p class="type-value">Circles info:</p>
					<p class="value">Lorem ipsum dolor sit amet, eu quem accumsan adipisci ius, per erroribus quaerendum in. Ne paulo invidunt nam. Primis facete philosophia et sed, pri feugait lobortis cu. His agam viderer et. Hinc idque feugiat te vis, has ei dicit legendos. Cu nullam blandit duo, eam aperiri petentium argumentum ut, cum quas probo in.</p>
				</div>
			</div>
		</div>
	</div>
</div>
