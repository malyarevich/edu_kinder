
<div class="well well-lg">
    <div class="container-fluid">
        <div class="list-group">
            <?php
             $con = mysqli_connect("localhost", "simpy", "password", "kinder_garden") or die("Error " . mysqli_error($con));
// $sql = "SELECT * FROM list_of_section inner join sections where sections.id_section=list_of_section.id_section";
$sql = "SELECT * FROM sections";
$result = mysqli_query($con,$sql);

while($row = mysqli_fetch_array($result)) {
    $sectionID = $row['id_section'];
    $title = $row['name_of_section'];
    $description = $row['short_info'];
    $path= $row['icon_path'];
?>
            <a href="#circles.php<?php echo '?sectionID='.$sectionID; ?>" style="margin-bottom:10px;" class="list-group-item">
                <div class="media col-sm-3 col-md-2">
                    <figure>
                        <img class="circle-pic img-rounded img-responsive " src="<?php echo $path; ?>" alt="circlePic">
                    </figure>
                </div>
                <div class=" col-sm-9 col-md-10">
                    <h3 class="list-group-item-heading"><?php echo $title; ?></h3>
                    <p class="contentTitle"><strong>Short Info:</strong></p>
                    <p class="list-group-item-text">
                        <?php echo $description; ?>
                    </p>
                </div>
                <div class="clearfix"></div>
            </a>
         <?php  } 

 ?>

        </div>
    </div>
</div>
