<?php
//connect to mysql database
 $con = mysqli_connect("localhost", "simpy", "password", "kinder_garden") or die("Error " . mysqli_error($con));
?>