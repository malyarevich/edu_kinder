<?php
session_start();

include_once 'dbconnect.php';
?>
<!DOCTYPE html>
<html>

<head>
    <title>Kinder Surprise</title>
    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- MetisMenu CSS -->
    <link href="css/plugins/metisMenu/metisMenu.min.css" rel="stylesheet">
    <!-- Timeline CSS -->
    <link href="css/plugins/timeline.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/sb-admin-2.css" rel="stylesheet">
    <!-- Morris Charts CSS -->
    <link href="css/plugins/morris.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">

</head>

<body>
   
    <div class="container-fluid">
         <div id="fullscreen_bg" class="fullscreen_bg"/>
            <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12">
                            <p style="margin-top:40px;" class="customTitle text-center" href="index.html">Kindergarden</p>
                        </div>
                          </div>
                             <div style="margin-top:70px;" class="row">
                <div class="text col-sm-7 col-md-7 col-lg-7 text-center">
                    <div class="well well-lg custom-well ">
                       <p class="customTitle1">Wellcome to our kindergarden network. </p> 
                       <p class="customTitle1">Please login! </p> 
                       
                    </div>
                </div>
                <div class="text col-sm-5 col-md-5 col-lg-5">
                    <div class="well well-lg custom-well">
                        <div class="panel-body">
                            <form role="form">
                                <fieldset>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="E-mail" required value="" class="form-control" name="email" type="email" autofocus>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" placeholder="Password" name="password" type="password" required value="" class="form-control">
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                 <input name="remember" type="checkbox" value="Remember Me">Remember Me
                                 </label>
                                    </div>
                                    <!-- Change this to a button or input when using this as a form -->
                                    <button  class="btn btn-lg btn-success btn-block">Login</button>
                                </fieldset>
                       
                        </form>
                    </div>
                </div>
            </div>

            </div>
      
    </div>
    <script src="js/bootstrap.min.js"></script>
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

</body>

</html>
