# [Start Bootstrap](http://startbootstrap.com/) - [Kinder Surprise taiga.io](https://tree.taiga.io/project/malyarevich-kindersurprise/taskboard/2nd-sprint-48)

[Kinder Surprise](http://startbootstrap.com/template-overviews/sb-admin-2/) is an open educational project.



## Bugs and Issues

Have a bug or an issue with this project? [Open a new issue](https://github.com/malyarevich/malyarevich.kinder/issues) here on GitHub or leave a comment.

## Creator

Kinder Surprise was created by and is maintained by **Paul Malyarevich**, **Maks Fedorenchik**, **Aleksey Ohmat**, **Nadia Trofimova**, **Valeria Petrikovskaya** and other.

* https://tree.taiga.io/project/malyarevich-kindersurprise/
* https://github.com/malyarevich/malyarevich.kinder/



## Copyright and License

Copyright 2017 Kinder Surprise. Code released under the Crutches. 
